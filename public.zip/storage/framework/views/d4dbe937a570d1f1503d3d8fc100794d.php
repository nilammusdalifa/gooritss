<?php if (isset($component)) { $__componentOriginal9f7656e55fcaa4534bc891f065ed3408 = $component; } ?>
<?php $component = App\View\Components\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Base::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('materialIsActive', null, []); ?> 
        <?php echo e($materialIsActive); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('ppIsActive', null, []); ?> 
        <?php echo e($ppIsActive); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('ccIsActive', null, []); ?> 
        <?php echo e($ccIsActive); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('pcIsActive', null, []); ?> 
        <?php echo e($pcIsActive); ?>

     <?php $__env->endSlot(); ?>

    <div class="p-5">
        <div class="card w-50 mx-auto" id="productCard">
            <div class="card-header">
                <div class="card-title">
                    <h3>Insert Product's Component</h3>
                </div>
            </div>
            <div class="card-body">
                <form id="insertProductComponent">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="productName" class="form-label">Product Name</label>
                        <input type="text" class="form-control" name="productName">
                    </div>
                    <div class="mb-3">
                        <label for="rawComponentName" class="form-label">Raw Component Name</label>
                        <div id="componentContainer">
                            <div class="row">
                                <div class="col">
                                    <div class="mb-3">
                                        <select class="form-select select2-custom" name="rawComponentName">
                                            <option></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col">
                                    <input type="number" class="form-control form-control-sm" name="rawComponentQty">
                                </div>
                            </div>

                        </div>
                        <button type="button" class="btn btn-primary" id="addRawComponent">+</button>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="template" hidden>
        <div id="template" class="row">
            <div class="col">
                <div class="mb-3">
                    <select class="form-select select2-custom" name="rawComponentName">
                        <option></option>
                    </select>
                </div>
            </div>
            <div class="col">
                <input type="number" class="form-control form-control-sm" name="rawComponentQty">
            </div>
        </div>
    </div>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            document.addEventListener('DOMContentLoaded', function() {

                let allComponent = []
                $(async function() {
                    allComponent = await getComponents()
                    initSelect2()
                })

                $('#insertProductComponent').on('submit', async (e) => {
                    e.preventDefault()
                    let productName = $('[name="productName"]').val()
                    let componentIds = $('.select2-custom').val()

                    let data = {
                        productName: productName,
                        componentIds: componentIds,
                    }

                    try {
                        let result = await insertProductComponent(data)
                        $('#insertProductComponent').trigger('reset')
                        alert(result)
                    } catch (error) {
                        alert(error)
                    }
                })

                $('#addRawComponent').on('click', () => {
                    let clonedEl = $('#template').clone()
                    console.log(clonedEl);
                    $(clonedEl).removeAttr('id')
                    $(clonedEl).find('.select2-custom').empty()
                    $(clonedEl).find('.select2-custom').select2({
                        data: allComponent,
                        width: '100%',
                        dropdownParent: $('#productCard')
                    })
                    $('#componentContainer').append(clonedEl)
                })

                async function initSelect2() {
                    allComponent = generateComponentDropdown(allComponent)
                    $('.select2-custom').empty()
                    $('.select2-custom').select2({
                        data: allComponent,
                        width: '100%'
                    })
                }

                function insertProductComponent(param) {
                    return new Promise((resolve, reject) => {
                        $.ajax({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            method: 'POST',
                            url: route('pc-insert-product-component'),
                            data: param,
                            success: function(data) {
                                resolve(data)
                            },
                            error: function(e) {
                                reject(e)
                            }
                        })
                    })
                }

                function getComponents() {
                    return new Promise((resolve, reject) => {
                        $.ajax({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            method: 'GET',
                            url: route('pp-get-car-components'),
                            success: function(data) {
                                console.log(data)
                                resolve(data)
                            },
                            error: function(e) {
                                reject(e)
                            }
                        });
                    })
                }

                function generateComponentDropdown(data) {
                    tempData = []
                    for (var i in data) {
                        var t = {
                            id: data[i].id,
                            text: data[i].name
                        }
                        tempData.push(t)
                    }
                    return tempData
                }

                function setMinLength(el) {
                    if (el.value != "") {
                        if (parseInt(el.value) < parseInt(el.min)) {
                            el.value = el.min;
                        }
                    }
                }
            })
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f7656e55fcaa4534bc891f065ed3408)): ?>
<?php $component = $__componentOriginal9f7656e55fcaa4534bc891f065ed3408; ?>
<?php unset($__componentOriginal9f7656e55fcaa4534bc891f065ed3408); ?>
<?php endif; ?>
<?php /**PATH H:\Nilam\KERJA!!\Coding Excercise\applications\test-laravel\resources\views/pages/product_component.blade.php ENDPATH**/ ?>