<?php if (isset($component)) { $__componentOriginal9f7656e55fcaa4534bc891f065ed3408 = $component; } ?>
<?php $component = App\View\Components\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Base::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-6">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        Halo
                    </div>
                </div>
                <div class="card-body">
                    <form id="formInsertComponent">
                        <div class="mb-3">
                            <label for="componentName" class="form-label">Component Name</label>
                            <input type="text" class="form-control" name="componentName">
                        </div>
                        <div class="mb-3">
                            <label for="stock" class="form-label">Stock</label>
                            <input type="number" minlength="1" class="form-control" name="componentStock">
                        </div>
                        <div class="mb-3">
                            <label for="cost" class="form-label">Cost</label>
                            <input type="number" minlength="1" class="form-control" name="componentCost">
                        </div>
                        <div class="mb-3">
                            <label for="production_time" class="form-label">Production Time</label>
                            <input type="number" minlength="1" class="form-control" name="productionTime">
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        Halo
                    </div>
                </div>
                <div class="card-body">
                    <form>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="componentName" class="form-label">Material Name</label>
                            <input type="text" class="form-control" name="componentName">
                        </div>
                        <div class="mb-3">
                            <label for="stock" class="form-label">Stock</label>
                            <input type="number" minlength="1" class="form-control" name="materialStock">
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $('#formInsertComponent').on('submit', async (e) => {
                e.preventDefault()
                let data = $('#formInsertComponent').serialize()
                try {
                    let result = await insertComponent(data)
                    console.log(result)
                } catch (error) {
                    alert(error)
                }
            })

            function insertComponent(param) {
                return new Promise((resolve, reject) => {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        method: 'POST',
                        url: route('cm-insert'),
                        data: param,
                        success: function(data) {
                            console.log(data);
                            resolve(data)
                        },
                        error: function(e) {
                            console.log(e);
                            reject(e)
                        }
                    })
                })
            }
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f7656e55fcaa4534bc891f065ed3408)): ?>
<?php $component = $__componentOriginal9f7656e55fcaa4534bc891f065ed3408; ?>
<?php unset($__componentOriginal9f7656e55fcaa4534bc891f065ed3408); ?>
<?php endif; ?>
<?php /**PATH H:\Nilam\KERJA!!\Coding Excercise\applications\test-laravel\resources\views/pages/material.blade.php ENDPATH**/ ?>