<?php if (isset($component)) { $__componentOriginal9f7656e55fcaa4534bc891f065ed3408 = $component; } ?>
<?php $component = App\View\Components\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Base::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                Halo
            </div>
        </div>
        <div class="card-body">
            <form>
                <div class="row">
                    <label for="totalCar" class="form-label">Total Car</label>
                    <div class="col">
                        <input type="number" class="form-control" id="totalCar">
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" type="submit">Generate</button>
                    </div>
                </div>
            </form>

            <table class="table table-bordered mt-5">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Component Name</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Stock Status</th>
                        <th scope="col">Total Price</th>
                        <th scope="col">Total Time</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f7656e55fcaa4534bc891f065ed3408)): ?>
<?php $component = $__componentOriginal9f7656e55fcaa4534bc891f065ed3408; ?>
<?php unset($__componentOriginal9f7656e55fcaa4534bc891f065ed3408); ?>
<?php endif; ?>
<?php /**PATH H:\Nilam\KERJA!!\Coding Excercise\applications\test-laravel\resources\views/pages/production_planning.blade.php ENDPATH**/ ?>