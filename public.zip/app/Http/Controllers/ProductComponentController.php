<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Ramsey\Uuid\Uuid;

class ProductComponentController extends Controller
{
    public function insertProductComponents(Request $request) {
        try {
            $productName = $request->post('productName');
            $componentIds = $request->post('componentIds');
            $rawComponents = [];
            $productId = Uuid::uuid4();
            DB::table('products')->insert([
                'id' => $productId,
                'name' => $productName
            ]);

            for ($i = 0; $i < count($componentIds); $i++) {
                $data = [
                    'products_id' => $productId,
                    'raw_components_id' => $componentIds[$i]
                ];

                array_push($rawComponents, $data);
            }

            DB::table('products_has_raw_components')->insert($rawComponents);

            return('Success');
        } catch (\Throwable $th) {
            return $th;
        }
    }
}
