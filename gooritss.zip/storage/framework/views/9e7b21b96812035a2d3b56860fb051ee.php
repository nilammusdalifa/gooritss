<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
</head>
<body>
    <h1>Posts Page</h1>
</body>
</html>
<?php /**PATH H:\Nilam\KERJA!!\Coding Excercise\applications\test-laravel\resources\views/posts.blade.php ENDPATH**/ ?>