<div class="d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary" style="width: 300px; height: 100vh"
    data-bs-theme="dark">
    <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <span class="fs-4">Menu</span>
    </a>
    <hr />
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a href="/page/component-raw-material" class="nav-link <?php echo e($materialIsActive); ?> link-body-emphasis"
                aria-current="page">
                Raw Components and Materials
            </a>
        </li>
        <li>
            <a href="/page/production-planning" class="nav-link <?php echo e($ppIsActive); ?> link-body-emphasis">
                Production Planning
            </a>
        </li>
        <li>
            <a href="/page/car-component" class="nav-link <?php echo e($ccIsActive); ?> link-body-emphasis">
                Car Components
            </a>
        </li>
        <li>
            <a href="/page/product-component" class="nav-link <?php echo e($pcIsActive); ?> link-body-emphasis">
                Products
            </a>
        </li>
    </ul>
</div>
<?php /**PATH H:\Nilam\KERJA!!\Coding Excercise\applications\test-laravel\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>